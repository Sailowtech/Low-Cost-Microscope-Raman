Le code présent m'a permis de faire fonctionner le capteur photo pour faire des tests préliminaires, mais ne permet pas de faire fonctionner le capteur comme prévu.
Il faut, je pense, ajouter dans le circuit électrique une horloge externe et faire uniquement le processing avec le microcontroller.
Le circuit électrique pour brancher le MC est disponible dans le PDF dans ce dossier. 
Attention, il faut bien connecter les 2 VDD et GND du capteur, sinon il ne fonctionne pas.
S'il vous reste des questions, n'hésitez pas à m'envoyer sur Telegram à @xamence.